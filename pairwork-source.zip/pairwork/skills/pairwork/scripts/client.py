#!/usr/bin/env python3
"""Browser-approved local demo connection; standard library only."""
import json, os, sys, time, urllib.request, urllib.error, webbrowser
from pathlib import Path
from urllib.parse import urlparse
BASE=os.environ.get('PAIRWORK_URL','http://127.0.0.1:8765').rstrip('/')
u=urlparse(BASE)
if u.scheme!='http' or u.hostname not in ('127.0.0.1','localhost'):raise SystemExit('This demo client only connects to loopback HTTP.')
STORE=Path(os.environ.get('PAIRWORK_SESSION',str(Path(__file__).resolve().parent.parent/'.session.json')))
def call(path,data=None,token=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 r=urllib.request.Request(BASE+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
 try:
  with urllib.request.urlopen(r,timeout=15) as f:return json.load(f)
 except urllib.error.HTTPError as e:raise SystemExit(e.read().decode())
def main():
 cmd=sys.argv[1] if len(sys.argv)>1 else 'help'
 if cmd=='connect':
  d=call('/api/device/start',{});print('Choose a demo team in your browser and approve the connection:\n'+d['url'],flush=True);webbrowser.open(d['url'])
  for _ in range(150):
   r=call('/api/device/poll',{'code':d['code']})
   if 'token' in r:
    STORE.parent.mkdir(exist_ok=True,parents=True)
    fd=os.open(STORE,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as f:json.dump(r,f)
    print('Connected as team: '+r['pair']);return
   time.sleep(2)
  raise SystemExit('Connection timed out. Run connect again.')
 if cmd=='help':print('connect | get_jobs | get_balance | get_pair_profile | create_job JSON | accept_job JSON | submit_job JSON | approve_result JSON | reject_result JSON');return
 if not STORE.exists():raise SystemExit('Run connect first.')
 token=json.loads(STORE.read_text())['token'];profile=call('/api/profile',token=token)
 if not profile.get('pair'):raise SystemExit('Session expired. Run connect again.')
 if cmd in ('get_jobs','get_balance','get_pair_profile'):
  s=call('/api/state',token=token)['state'];out=s['jobs'] if cmd=='get_jobs' else next(p for p in s['pairs'] if p['id']==profile['pair'])
 else:
  args=json.loads(sys.argv[2]) if len(sys.argv)>2 else {};out=call('/api/action',{'action':cmd,'args':args},token)['job']
 print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
