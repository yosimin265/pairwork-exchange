import importlib.util, pathlib, tempfile, os, unittest, concurrent.futures
os.environ['PAIRWORK_DATA']=tempfile.mkdtemp()
p=pathlib.Path(__file__).resolve().parents[1]/'server.py'
spec=importlib.util.spec_from_file_location('pw',p);pw=importlib.util.module_from_spec(spec);spec.loader.exec_module(pw)
class ExchangeTests(unittest.TestCase):
 def setUp(self):
  with pw.connection() as c:c.execute('UPDATE state SET data=? WHERE id=1',(pw.json.dumps(pw.seed()),))
 def prepare(self):
  pw.mutate('b','accept_job',{'job_id':'job-001'});pw.mutate('b','submit_job',{'job_id':'job-001','result':'Translated README'})
 def test_exchange_and_second_job(self):
  self.prepare();pw.mutate('a','approve_result',{'job_id':'job-001'});s=pw.read_state();self.assertEqual([p['balance'] for p in s['pairs']],[250,350]);self.assertEqual(sum(x['amount'] for x in s['ledger']),0)
  j=pw.mutate('b','create_job',{'title':'Review','description':'Review this function','points':50})['job'];pw.mutate('a','accept_job',{'job_id':j['id']});pw.mutate('a','submit_job',{'job_id':j['id'],'result':'Check empty input'});pw.mutate('b','approve_result',{'job_id':j['id']});self.assertEqual([p['balance'] for p in pw.read_state()['pairs']],[300,300])
 def test_wrong_actor_and_self_accept(self):
  with self.assertRaises(ValueError):pw.mutate('a','accept_job',{'job_id':'job-001'})
  self.prepare()
  with self.assertRaises(ValueError):pw.mutate('b','approve_result',{'job_id':'job-001'})
 def test_concurrent_approval_once(self):
  self.prepare()
  def approve(_):
   try:pw.mutate('a','approve_result',{'job_id':'job-001'});return True
   except ValueError:return False
  with concurrent.futures.ThreadPoolExecutor(8) as pool:r=list(pool.map(approve,range(8)))
  self.assertEqual(sum(r),1);self.assertEqual(len(pw.read_state()['ledger']),2)
 def test_reserved_balance(self):
  pw.mutate('a','create_job',{'title':'Large','description':'Work','points':250})
  with self.assertRaises(ValueError):pw.mutate('a','create_job',{'title':'Extra','description':'Work','points':1})
 def test_revision_no_transfer(self):
  self.prepare();pw.mutate('a','reject_result',{'job_id':'job-001'});self.assertEqual(pw.read_state()['ledger'],[])
  pw.mutate('b','submit_job',{'job_id':'job-001','result':'Revised'});pw.mutate('a','approve_result',{'job_id':'job-001'});self.assertEqual(pw.read_state()['jobs'][0]['status'],'completed')
 def test_proof_changes_with_result(self):
  self.prepare();j=pw.mutate('a','approve_result',{'job_id':'job-001'})['job'];self.assertEqual(j['proof']['result_hash'],pw.hashlib.sha256(b'Translated README').hexdigest());self.assertEqual(len(j['hash']),64)
if __name__=='__main__':unittest.main()
